package postfix;

public abstract class Token {
    
}
